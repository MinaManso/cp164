"""
-------------------------------------------------------
t03.py
-------------------------------------------------------
Author:  Mina Mansour
ID:      210139740
Email:   mans3974@mylaurier.ca
__updated__ = "2024-05-11"
-------------------------------------------------------
"""
# Imports
from functions import is_palindrome


# Constants

print(is_palindrome('racecar'))
print(is_palindrome('hello'))
print(is_palindrome('a'))
print(is_palindrome('was it a car or a cat I saw?'))
print(is_palindrome("No lemon, no melon"))