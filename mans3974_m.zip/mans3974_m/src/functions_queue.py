"""
-------------------------------------------------------
Queue Functions
-------------------------------------------------------
Author: Mina Mansour
ID:     210139740
Email:  mans3974@mylaurier.ca
__updated__ = "2024-06-09"
-------------------------------------------------------
"""
# pylint: disable=E0303
# pylint: disable=E1128
# pylint: disable=E2515
# pylint: disable=W0212
# pylint: disable=W0613

# Imports
from Queue_array import Queue
from pickle import TRUE


def threads_weave(threads):
    """
    -------------------------------------------------------
    Combines multiple Queues into one Queue where the multiple Queue
    values are interwoven into the returned Queue. Values are removed
    from each Queue in threads.
    Use: singleton = threads_weave(threads)
    -------------------------------------------------------
    Parameters:
        threads - a list of Queues to process (list of Queue)
    Returns‌‌​​‌​​​​‌‌​​‌‌‌‌​‌​​‌​‌‌‌​​:
        singleton - a Queue (Queue)
    -------------------------------------------------------
    """
    #begin a queue
    combine = Queue()
    #active until not
    queue = True
    
    while queue:
        queue = False 
        
        
        
        for thread in threads:
            if not thread.is_empty():
                
                
        
                combine.insert(thread.remove())
                
                
                queue = True
    

    return combine


def queue_rotate(source, n):
    """
    -------------------------------------------------------
    Rotates position of values in source, meaning moving its contents
    from the front to the rear n times.
    Use: queue_rotate(source, n)
    -------------------------------------------------------
    Parameters:
        source - the Queue to rotate (Queue)
        n - amount to rotate Queue values (int)
    Returns‌‌​​‌​​​​‌‌​​‌‌‌‌​‌​​‌​‌‌‌​​:
        None
    -------------------------------------------------------
    """
    
   
    
    size = len(source)
    
    n = n % size 
    
    for _ in range(n):
        source.insert(source.remove())
    
    

    return
