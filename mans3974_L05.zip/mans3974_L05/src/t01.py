"""
-------------------------------------------------------
[program description]
-------------------------------------------------------
Author:  Mina Mansour
ID:      210139740
Email:   mans3974@mylaurier.ca
__updated__ = "2024-06-08"
-------------------------------------------------------
"""
# Imports

# Constants

from functions import recurse

result = recurse(2,3)
print(result)