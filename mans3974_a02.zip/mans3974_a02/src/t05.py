from mans3974_data_structures import Movie_utilities

def test_genre_count():
    """
    -------------------------------------------------------
    Tests Movie_utilities.genre_count.
    Use: test_genre_count()
    -------------------------------------------------------
    """
    count = Movie_utilities.genre_count()
    print(count)
    
    return
