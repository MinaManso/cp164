from mans3974_data_structures import Movie_utilities

def test_get_by_year():
    """
    -------------------------------------------------------
    Tests Movie_utilities.get_by_year.
    Use: test_get_by_year()
    -------------------------------------------------------
    """
    movies = Movie_utilities.get_by_year(1999)
    for m in movies:
        print(m)
    

    return


